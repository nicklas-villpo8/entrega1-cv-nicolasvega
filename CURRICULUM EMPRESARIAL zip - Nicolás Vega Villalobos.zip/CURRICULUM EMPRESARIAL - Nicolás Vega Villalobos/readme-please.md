<!-- 
ALUMNO: Nicolás Vega Villalobos
DNI: 37636950
CORREO ELECTRÓNICO: nicolavillalupo@gmail.com
CURSO: Desarrollo Front-End

NOMBRE DEL PROYECTO: Curriculum para empresa ("Heladerías Villpo") // una pagina web con un curriculum capaz de cargar datos alfanuméricos con la posibilidad de ser enviados

-->