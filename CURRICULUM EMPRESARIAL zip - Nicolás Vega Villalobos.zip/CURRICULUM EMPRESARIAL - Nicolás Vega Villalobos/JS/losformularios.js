const formulario = document.getElementById("Formulario");
const inputs = document.querySelectorAll("#Formulario input")

const expresiones = {
	nombre: /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
	apellido:  /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
	dni:/^\d{6,10}$/, // 6 a 10 numeros.
    género:/^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
	correoelectronico: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
	celular: /^\d{7,16}$/, // 7 a 16 numeros.
	domicilio:/^[a-zA-ZÀ-ÿ-Z0-9\s]{1,40}$/, // Letras, números y espacios, pueden llevar acentos.
	estadolaboral:/^[a-zA-ZÀ-ÿ\s]{1,2}$/, // Letras y espacios, pueden llevar acentos.
	historial:/^[a-zA-ZÀ-ÿ-Z0-9\s]{1,2000}$/, // Letras, números y espacios, pueden llevar acentos.

}

const campos = {
	nombre: false,
	apellido: false,  
	dni: false,
    género: false,
	correoelectronico: false,
	celular: false,
	domicilio: false,
	estadolaboral: false,
	historial: false,
}

const validarFormulario = (e) => {
     switch (e.target.name) {
		case "nombre":
              validarCampo(expresiones.nombre, e.target, "nombre");
		break;

		case "apellido":
			  validarCampo(expresiones.apellido, e.target, "apellido");
		break;

		case "dni":
			  validarCampo(expresiones.dni, e.target, "dni");
		break;

		case "género":
			  validarCampo(expresiones.género, e.target, "género");
		break;

		case "correoelectronico":
			  validarCampo(expresiones.correoelectronico, e.target, "correoelectronico");
		break;

		case "celular":
			  validarCampo(expresiones.celular, e.target, "celular");
		break;

		case "domicilio":
			  validarCampo(expresiones.domicilio, e.target, "domicilio");
		break;

		case "estadolaboral":
			  validarCampo(expresiones.estadolaboral, e.target, "estadolaboral");
		break;

		case "historial":
              validarCampo(expresiones.historial, e.target, "historial");
		break;
	 }
}

const validarCampo = (expresion, input, campo) => {
	if (expresion.test(input.value)) {
	    document.getElementById(`grupo__${campo}`).classList.remove("formulario__grupo-incorrecto");
		document.getElementById(`grupo__${campo}`).classList.add("formulario__grupo-correcto");
		document.querySelector(`grupo__${campo} .formulario__input-error`).classList.remove("formulario__input-error-activo");
         campos[campo] = true;
	} else {
		document.getElementById(`grupo__${campo}`).classList.add("formulario__grupo-incorrecto");
		document.getElementById(`grupo__${campo}`).classList.remove("formulario__grupo-correcto");
		document.querySelector(`grupo__${campo} .formulario__input-error`).classList.add("formulario__input-error-activo");
		campos[campo] = false;
    }
}

inputs.forEach((input) => {
     input.addEventListener("keyup", validarFormulario);
	 input.addEventListener("blur", validarFormulario);
})

formulario.addEventListener("submit", (e) => {
	e.preventDefault(); 

	if (campos.nombre && campos.apellido && campos.dni && campos.género && campos.correoelectronico && campos.celular && campos.domicilio && campos.estadolaboral && campos.historial){
	} else {
		formulario.reset();
	   
	}
})
